open Loop

let _ = loopFile "turing.fj" (step (wait showType));
